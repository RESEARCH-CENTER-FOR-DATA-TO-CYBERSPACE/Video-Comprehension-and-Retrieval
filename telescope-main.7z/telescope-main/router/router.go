package router

import (
	"github.com/SalieriAI/telescope/controller"
	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
)

type Router struct {
	ge   *gin.Engine
	ctrl *controller.Controller
}

func New(ctrl *controller.Controller) *Router {
	ge := gin.Default()
	ge.Use(cors.Default())

	r := &Router{ge: ge, ctrl: ctrl}

	r.routeAPI()

	return r
}

func (r *Router) routeAPI() {
	root := r.ge.Group("/api")

	root.POST("/create-table", r.ctrl.CreateTable)
	root.POST("/add-entries", r.ctrl.AddEntries)
	root.POST("/search", r.ctrl.Search)
	root.POST("/update-entries", r.ctrl.UpdateEntries)
	root.POST("/last-entries", r.ctrl.LastEntries)
	root.POST("/dump-table", r.ctrl.DumpTable)
	root.POST("/dump-field", r.ctrl.DumpField)
}

func (r *Router) Run(port string) {
	r.ge.Run(port)
}
