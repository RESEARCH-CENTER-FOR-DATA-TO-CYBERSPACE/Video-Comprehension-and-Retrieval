package util

// If a doc contains an "id" field (type string), Typesense uses it as the identifier.
// Otherwise, Typesense would assign an identifier of its choice to the document.
const UniqueIDKey = "id"
