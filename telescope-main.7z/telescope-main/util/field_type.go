package util

const (
	ShortTextField = "shortText"
	LongTextField  = "longText"
	StringField    = "string"
	NumberField    = "number"
	ArrayField     = "array"
)

var fieldTypeSet = map[string]interface{}{
	ShortTextField: nil,
	LongTextField:  nil,
	StringField:    nil,
	NumberField:    nil,
	ArrayField:     nil,
}

// Return emtpy if the field type is not for SQL.
func FieldTypeToSqlType(fieldType string) string {
	if fieldType == StringField ||
		fieldType == ShortTextField ||
		fieldType == LongTextField {
		return "TEXT"
	}
	if fieldType == NumberField {
		return "DOUBLE"
	}
	if fieldType == ArrayField {
		return "JSON"
	}
	return ""
}

func ValidateFieldType(fieldType string) bool {
	_, ok := fieldTypeSet[fieldType]
	return ok
}
