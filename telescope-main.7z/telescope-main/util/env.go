package util

import (
	"fmt"
	"log"
	"os"
	"path/filepath"
	"runtime"
	"strings"
)

func LoadEnvironmentVariables() error {
	_, curFile, _, _ := runtime.Caller(0)
	env, err := os.ReadFile(
		filepath.Join(filepath.Dir(filepath.Dir(curFile)), ".env"))
	if err != nil {
		return err
	}

	lines := strings.Split(string(env), "\n")
	if len(lines) == 0 {
		return fmt.Errorf("no env variables found")
	}

	for _, line := range lines {
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}

		splitterIdx := strings.Index(line, "=")
		if splitterIdx < 0 {
			return fmt.Errorf("wrong env format: %s, should be VAR=VALUE", line)
		}
		key := strings.TrimSpace(line[:splitterIdx])
		val := strings.TrimSpace(line[splitterIdx+1:])
		if err := os.Setenv(key, val); err != nil {
			return err
		}
	}

	return nil
}

func MustGetenv(k string) string {
	v := os.Getenv(k)
	if v == "" {
		log.Fatalf("missing %s", k)
	}
	return v
}
