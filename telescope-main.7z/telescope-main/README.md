# telescope

## Local MySQL operations

Set user password:

```bash
mysql -u root
```

```mysql
UPDATE mysql.user SET authentication_string=null WHERE User='root';
FLUSH PRIVILEGES;
ALTER USER 'root'@'localhost' IDENTIFIED WITH 'mysql_native_password' BY '111111';
```

Initialize DB:

```bash
mysql -h localhost -u root -p -e "DROP DATABASE Telescope;"
mysql -h localhost -u root -p < store/init.sql
```

## Environment variables

Set the following environment variables in .env (ignored in .gitignore) under root directory:

- `MYSQL_HOST_ADDRESS`
- `MYSQL_USERNAME`
- `MYSQL_PASSWORD`
- `MYSQL_DB_NAME`
- `TYPESENSE_SERVER_URL`
- `TYPESENSE_API_KEY`

## Run program locally

To run the program, start `Docker`, then:

```
rm -rf typesense-data
mkdir $(pwd)/typesense-data
docker-compose up
go run main.go
```

## Integration test:

To run integration test:

```
cd test
python3 integration_test.py
```
