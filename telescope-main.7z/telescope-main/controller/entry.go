package controller

import (
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
)

type AddEntriesPostBody struct {
	TableName string `json:"tableName"`
	// Must contain all indexed fields.
	DataEntries []map[string]interface{} `json:"dataEntries"`
}

func (c *Controller) AddEntries(gc *gin.Context) {
	var b AddEntriesPostBody
	if err := gc.BindJSON(&b); err != nil {
		gc.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	if err := c.retriever.AddEntries(b.TableName, b.DataEntries); err != nil {
		gc.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	gc.JSON(http.StatusOK, nil)
}

type UpdateEntriesPostBody struct {
	TableName string `json:"tableName"`
	// Must contain a field “id”, the same one returned by /search.
	DataEntries []map[string]interface{} `json:"dataEntries"`
}

func (c *Controller) UpdateEntries(gc *gin.Context) {
	var b UpdateEntriesPostBody
	if err := gc.BindJSON(&b); err != nil {
		gc.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	if err := c.retriever.UpdateEntries(b.TableName, b.DataEntries); err != nil {
		gc.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	gc.JSON(http.StatusOK, nil)
}

type LastEntriesPostBody struct {
	TableName string `json:"tableName"`
	Limit     int    `json:"limit"`
}

func (c *Controller) LastEntries(gc *gin.Context) {
	var b LastEntriesPostBody
	if err := gc.BindJSON(&b); err != nil {
		gc.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	if b.Limit <= 0 {
		gc.AbortWithStatusJSON(http.StatusBadRequest,
			gin.H{"error": fmt.Sprintf("wrong limit: %d", b.Limit)})
		return
	}

	entries, err := c.retriever.LastEntries(b.TableName, b.Limit)
	if err != nil {
		gc.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	gc.JSON(http.StatusOK, entries)
}
