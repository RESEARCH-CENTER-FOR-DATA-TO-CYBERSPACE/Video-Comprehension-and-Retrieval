package controller

import (
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
)

type SearchPostBody struct {
	TableName string `json:"tableName"`
	FieldName string `json:"fieldName"`
	Query     string `json:"query"`
}

func (c *Controller) Search(gc *gin.Context) {
	var b SearchPostBody
	if err := gc.BindJSON(&b); err != nil {
		gc.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	res, err := c.retriever.Search(b.TableName, b.FieldName, b.Query)
	if err != nil {
		gc.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	gc.JSON(http.StatusOK, res)
}

type DumpTablePostBody struct {
	TableName string `json:"tableName"`
	// -1 means no limit, use with caution.
	Limit int `json:"limit"`
}

func (c *Controller) DumpTable(gc *gin.Context) {
	var b DumpTablePostBody
	if err := gc.BindJSON(&b); err != nil {
		gc.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	if b.Limit <= 0 && b.Limit != -1 {
		gc.AbortWithStatusJSON(http.StatusBadRequest,
			gin.H{"error": fmt.Sprintf("wrong limit: %d", b.Limit)})
		return
	}

	res, err := c.store.DumpTable(b.TableName, b.Limit)
	if err != nil {
		gc.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	gc.JSON(http.StatusOK, res)
}

type DumpFieldPostBody struct {
	TableName string `json:"tableName"`
	FieldName string `json:"fieldName"`
	// -1 means no limit, use with caution.
	Limit int `json:"limit"`
}

func (c *Controller) DumpField(gc *gin.Context) {
	var b DumpFieldPostBody
	if err := gc.BindJSON(&b); err != nil {
		gc.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	if b.Limit <= 0 && b.Limit != -1 {
		gc.AbortWithStatusJSON(http.StatusBadRequest,
			gin.H{"error": fmt.Sprintf("wrong limit: %d", b.Limit)})
		return
	}

	res, err := c.store.DumpField(b.TableName, b.FieldName, b.Limit)
	if err != nil {
		gc.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	gc.JSON(http.StatusOK, res)
}
