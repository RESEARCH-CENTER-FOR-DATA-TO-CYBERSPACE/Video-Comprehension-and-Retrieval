package controller

import (
	"net/http"

	"github.com/SalieriAI/telescope/retriever"
	"github.com/gin-gonic/gin"
)

type CreateTablePostBody struct {
	TableName string `json:"tableName"`
	// Index fields must be a subset of all fields in DataEntry.
	IndexFields []*retriever.IndexField `json:"indexFields"`
	// Optional. If empty, default to multilingual-e5-large (512 token limit).
	EmbeddingModel string `json:"embeddingModel"`
}

func (c *Controller) CreateTable(gc *gin.Context) {
	var b CreateTablePostBody
	if err := gc.BindJSON(&b); err != nil {
		gc.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	if err := c.retriever.CreateTable(
		b.TableName, b.EmbeddingModel, b.IndexFields); err != nil {
		gc.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	gc.JSON(http.StatusOK, nil)
}
