package controller

import (
	"github.com/SalieriAI/telescope/retriever"
	"github.com/SalieriAI/telescope/store"
)

type Controller struct {
	retriever *retriever.Retriever
	store     *store.Store
}

func New(retriever *retriever.Retriever, store *store.Store) *Controller {
	return &Controller{retriever: retriever, store: store}
}
