import json
import requests
import random
import string

_ENDPOINT = "http://localhost:5050/api"

_TABLE_NAME = ''.join(random.choices(string.ascii_letters, k=5))


def read_ndjson_file(file_path):
    data = []
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            data.append(json.loads(line))
    return data


def create_table():
    res = requests.post(_ENDPOINT + "/create-table", timeout=300, json={
        "tableName": _TABLE_NAME,
        "indexFields": [
            {"name": "name", "type": "shortText"},
            {"name": "description", "type": "longText"},
            {"name": "url", "type": "string"},
            {"name": "impact_areas", "type": "array"},
            {"name": "age", "type": "number"}
        ],
    })
    if res.status_code == 200:
        print("Succeeded to call /create-table...")
    else:
        print("Failed to call /create-table: " + res.text)


def add_entries():
    res = requests.post(_ENDPOINT + "/add-entries", timeout=300, json={
        "tableName": _TABLE_NAME,
        "dataEntries": read_ndjson_file("./csail_groups.ndjson"),
    })
    if res.status_code == 200:
        print("Succeeded to call /add-entries...")
    else:
        print("Failed to call /add-entries: " + res.text)


def search_long_text():
    res = requests.post(_ENDPOINT + "/search", timeout=300, json={
        "tableName": _TABLE_NAME,
        "fieldName": "description",
        "query": "Advanced robotics"
    })
    if res.status_code == 200:
        print("Succeeded to call /search for long text...")
    else:
        print("Failed to call /search for long text: " + res.text)
    print(res.text + "\n\n")


def search_string():
    res = requests.post(_ENDPOINT + "/search", timeout=300, json={
        "tableName": _TABLE_NAME,
        "fieldName": "url",
        "query": "/research/learning-and-intelligent-systems"
    })
    if res.status_code == 200:
        print("Succeeded to call /search for string...")
    else:
        print("Failed to call /search for string: " + res.text)
    print(res.text + "\n\n")


def search_array():
    res = requests.post(_ENDPOINT + "/search", timeout=300, json={
        "tableName": _TABLE_NAME,
        "fieldName": "impact_areas",
        "query": "Manufacturing"
    })
    if res.status_code == 200:
        print("Succeeded to call /search for array...")
    else:
        print("Failed to call /search for array: " + res.text)
    print(res.text + "\n\n")


def search_number():
    res = requests.post(_ENDPOINT + "/search", timeout=300, json={
        "tableName": _TABLE_NAME,
        "fieldName": "age",
        "query": "5"
    })
    if res.status_code == 200:
        print("Succeeded to call /search for number...")
    else:
        print("Failed to call /search for number: " + res.text)
    print(res.text + "\n\n")


def search_number_range():
    res = requests.post(_ENDPOINT + "/search", timeout=300, json={
        "tableName": _TABLE_NAME,
        "fieldName": "age",
        "query": "[11, 15)"
    })
    if res.status_code == 200:
        print("Succeeded to call /search for number range...")
    else:
        print("Failed to call /search for number range: " + res.text)
    print(res.text + "\n\n")


def update_entries():
    res = requests.post(_ENDPOINT + "/update-entries", timeout=300, json={
        "tableName": _TABLE_NAME,
        "dataEntries": [
            {
                "id": 2,
                "url": "/updated-url",
                "name": "updated name",
                "teaser": "updated teaser",
                "description": "updated description",
                "research_areas": ["AI"],
                "impact_areas": ["Robotics"],
                "persons": ["/harry-porter"],
                "age": 266
            }
        ]
    })
    if res.status_code == 200:
        print("Succeeded to call /update-entries...")
    else:
        print("Failed to call /update-entries: " + res.text)


def search_number_post_update():
    res = requests.post(_ENDPOINT + "/search", timeout=300, json={
        "tableName": _TABLE_NAME,
        "fieldName": "age",
        "query": "266"
    })
    if res.status_code == 200:
        print("Succeeded to call /search for number post update...")
    else:
        print("Failed to call /search for number post update: " + res.text)
    print(res.text + "\n\n")


def dump_table_limit_3():
    res = requests.post(_ENDPOINT + "/dump-table", timeout=300, json={
        "tableName": _TABLE_NAME,
        "limit": 3
    })
    if res.status_code == 200:
        print("Succeeded to call /dump-table for limit 3...")
    else:
        print("Failed to call /dump-table for limit 3: " + res.text)
    print(res.text + "\n\n")


def dump_table_no_limit():
    res = requests.post(_ENDPOINT + "/dump-table", timeout=300, json={
        "tableName": _TABLE_NAME,
        "limit": -1
    })
    if res.status_code == 200:
        print("Succeeded to call /dump-table for no limit...")
    else:
        print("Failed to call /dump-table for no limit: " + res.text)
    print(res.text + "\n\n")


def dump_field_name():
    """Short text."""
    res = requests.post(_ENDPOINT + "/dump-field", timeout=300, json={
        "tableName": _TABLE_NAME,
        "fieldName": "name",
        "limit": -1
    })
    if res.status_code == 200:
        print("Succeeded to call /dump-field for 'name' (no limit)...")
    else:
        print("Failed to call /dump-field for 'name' (no limit): " + res.text)
    print(res.text + "\n\n")


def dump_field_impact_areas():
    """Array."""
    res = requests.post(_ENDPOINT + "/dump-field", timeout=300, json={
        "tableName": _TABLE_NAME,
        "fieldName": "impact_areas",
        "limit": -1
    })
    if res.status_code == 200:
        print("Succeeded to call /dump-field for 'impact_areas' (no limit)...")
    else:
        print("Failed to call /dump-field for 'impact_areas' (no limit): " +
              res.text)
    print(res.text + "\n\n")


def last_entries():
    """Array."""
    res = requests.post(_ENDPOINT + "/last-entries", timeout=300, json={
        "tableName": _TABLE_NAME,
        "limit": 2
    })
    if res.status_code == 200:
        print("Succeeded to call /last-entries...")
    else:
        print("Failed to call /last-entries: " + res.text)
    print(res.text + "\n\n")


if __name__ == "__main__":
    print(f"\nTable name: {_TABLE_NAME}\n")
    create_table()
    add_entries()
    search_long_text()
    search_string()
    search_array()
    search_number()
    search_number_range()
    update_entries()
    search_number_post_update()
    dump_table_limit_3()
    dump_table_no_limit()
    dump_field_name()
    dump_field_impact_areas()
    last_entries()
