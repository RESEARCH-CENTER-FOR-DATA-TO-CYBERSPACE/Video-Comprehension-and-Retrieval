package main

import (
	"context"
	"flag"
	"log"

	"github.com/SalieriAI/telescope/controller"
	"github.com/SalieriAI/telescope/retriever"
	"github.com/SalieriAI/telescope/router"
	"github.com/SalieriAI/telescope/store"
	"github.com/SalieriAI/telescope/util"
)

var (
	port = flag.String("port", ":5050", "Port.")
)

func main() {
	ctx := context.Background()

	if err := util.LoadEnvironmentVariables(); err != nil {
		log.Fatalf("util.LoadEnvironmentVariables() = %s", err)
	}

	store, err := store.New()
	if err != nil {
		log.Fatalf("store.New() = %s", err)
	}

	retriever := retriever.New(ctx,
		util.MustGetenv("TYPESENSE_SERVER_URL"), util.MustGetenv("TYPESENSE_API_KEY"), store)
	ctrl := controller.New(retriever, store)

	r := router.New(ctrl)

	log.Printf("API server is running on port %s...\n", *port)
	r.Run(*port)
}
