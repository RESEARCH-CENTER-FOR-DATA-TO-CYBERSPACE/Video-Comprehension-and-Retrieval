package store

import (
	"fmt"

	"github.com/SalieriAI/telescope/util"
)

func (s *Store) HasTable(tableName string) bool {
	var exists bool
	if err := s.db.QueryRow(`
	SELECT COUNT(*) FROM information_schema.tables
	WHERE table_schema = ? AND table_name = ?
	`, s.dbName, tableName).Scan(&exists); err != nil {
		return false
	}
	return exists
}

func (s *Store) AddTable(
	tableName string,
	indexFieldToType map[string]string,
) error {
	if s.HasTable(tableName) {
		return fmt.Errorf("table %s is already stored", tableName)
	}

	tx, err := s.db.Begin()
	if err != nil {
		return err
	}

	var sqlFieldStmt string
	stmt, err := tx.Prepare(`
	INSERT INTO IndexFieldRegistry (
		TableName, FieldName, FieldType)
	VALUES (?, ?, ?)
	`)
	if err != nil {
		tx.Rollback()
		return err
	}
	for fieldName, fieldType := range indexFieldToType {
		if _, err := stmt.Exec(tableName, fieldName, fieldType); err != nil {
			tx.Rollback()
			return err
		}

		sqlType := util.FieldTypeToSqlType(fieldType)
		if sqlType != "" {
			sqlFieldStmt += fmt.Sprintf("%s %s NOT NULL,", fieldName, sqlType)
		}
	}

	idName := tableIDName(tableName)

	stmt, err = tx.Prepare(fmt.Sprintf(`
	CREATE TABLE IF NOT EXISTS %s (
		%s INT NOT NULL AUTO_INCREMENT,
		Payload JSON NOT NULL,
		%s
		PRIMARY KEY (%s)
	)`, tableName, idName, sqlFieldStmt, idName))
	if err != nil {
		tx.Rollback()
		return err
	}

	if _, err := stmt.Exec(); err != nil {
		tx.Rollback()
		return err
	}

	return tx.Commit()
}

func (s *Store) TableIndexFieldToType(tableName string) (map[string]string, error) {
	if !s.HasTable(tableName) {
		return nil, fmt.Errorf("cannot find table %s", tableName)
	}

	q, err := s.db.Query(`
	SELECT FieldName, FieldType
	FROM IndexFieldRegistry WHERE TableName = ?
	`, tableName)
	if err != nil {
		return nil, err
	}
	defer q.Close()

	fieldToType := map[string]string{}
	for q.Next() {
		var fieldName, fieldType string
		if err := q.Scan(&fieldName, &fieldType); err != nil {
			return nil, err
		}
		fieldToType[fieldName] = fieldType
	}
	return fieldToType, nil
}

func (s *Store) SqlTableIndexFieldToType(tableName string) (map[string]string, error) {
	fieldToType, err := s.TableIndexFieldToType(tableName)
	if err != nil {
		return nil, err
	}
	res := map[string]string{}
	for fieldName, fieldType := range fieldToType {
		if sqlType := util.FieldTypeToSqlType(fieldType); sqlType != "" {
			res[fieldName] = fieldType
		}
	}
	return res, nil
}
