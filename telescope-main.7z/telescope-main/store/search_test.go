package store

import "testing"

func TestParseNumberRange(t *testing.T) {
	for _, c := range []struct {
		numRange string
		wantErr  bool
		want     string
	}{
		{"[3,5]", false, "x >= 3 AND x <= 5"},
		{"[3, 5)", false, "x >= 3 AND x < 5"},
		{"(3, )", false, "x > 3"},
		{"( ,4)", false, "x < 4"},
		{"(4,a)", true, ""},
	} {
		got, err := parseNumberRange("x", c.numRange)
		if c.wantErr {
			if err == nil {
				t.Errorf("parseNumberRange(%s) = nil, want err", c.numRange)
			}
			continue
		}
		if err != nil {
			t.Errorf("parseNumberRange(%s) = %s", c.numRange, err)
			continue
		}
		if got != c.want {
			t.Errorf("parseNumberRange(%s) = %s, want %s", c.numRange, got, c.want)
		}
	}
}
