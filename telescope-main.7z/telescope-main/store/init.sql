CREATE DATABASE IF NOT EXISTS Telescope;

USE Telescope;

CREATE TABLE IF NOT EXISTS IndexFieldRegistry (
  IndexFieldRegistryId BIGINT NOT NULL AUTO_INCREMENT,
  TableName VARCHAR(255) NOT NULL,
  FieldName VARCHAR(255) NOT NULL,
  FieldType VARCHAR(255) NOT NULL,
  PRIMARY KEY (IndexFieldRegistryId)
);

CREATE INDEX IndexFieldRegistryIdx ON IndexFieldRegistry (TableName, FieldName);
