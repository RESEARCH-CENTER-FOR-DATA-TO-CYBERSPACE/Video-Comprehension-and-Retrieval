package store

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"

	"github.com/SalieriAI/telescope/util"
)

func (s *Store) StringSearch(
	tableName, fieldName, query string) ([]map[string]interface{}, error) {
	q, err := s.db.Query(fmt.Sprintf(`
	SELECT %s, Payload FROM %s WHERE %s = ?
	`, tableIDName(tableName), tableName, fieldName), query)
	if err != nil {
		return nil, err
	}
	defer q.Close()
	return getEntries(q)
}

func (s *Store) ArraySearch(
	tableName, fieldName, query string) ([]map[string]interface{}, error) {
	q, err := s.db.Query(fmt.Sprintf(`
		SELECT %s, Payload FROM %s WHERE JSON_CONTAINS(%s, '"%s"')
		`, tableIDName(tableName), tableName, fieldName, query))
	if err != nil {
		return nil, err
	}
	defer q.Close()
	return getEntries(q)
}

func (s *Store) NumberSearch(
	tableName, fieldName, query string) ([]map[string]interface{}, error) {
	if _, err := strconv.ParseFloat(query, 64); err == nil {
		// Exact number match is the same as string search.
		return s.StringSearch(tableName, fieldName, query)
	}

	sqlCondition, err := parseNumberRange(fieldName, query)
	if err != nil {
		return nil, err
	}

	q, err := s.db.Query(fmt.Sprintf(`
	SELECT %s, Payload FROM %s WHERE %s
	`, tableIDName(tableName), tableName, sqlCondition))
	if err != nil {
		return nil, err
	}
	defer q.Close()
	return getEntries(q)
}

func (s *Store) DumpTable(tableName string, limit int) ([]map[string]interface{}, error) {
	var limitStmt string
	if limit > 0 {
		limitStmt = fmt.Sprintf("LIMIT %d", limit)
	}
	q, err := s.db.Query(fmt.Sprintf(`
	SELECT %s, Payload FROM %s %s
	`, tableIDName(tableName), tableName, limitStmt))
	if err != nil {
		return nil, err
	}
	defer q.Close()
	return getEntries(q)
}

func (s *Store) DumpField(
	tableName, fieldName string, limit int) ([]interface{}, error) {
	var limitStmt string
	if limit > 0 {
		limitStmt = fmt.Sprintf("LIMIT %d", limit)
	}
	q, err := s.db.Query(fmt.Sprintf(`
	SELECT %s FROM %s %s
	`, fieldName, tableName, limitStmt))
	if err != nil {
		return nil, err
	}
	defer q.Close()

	fieldToType, err := s.TableIndexFieldToType(tableName)
	if err != nil {
		return nil, err
	}
	fieldType, ok := fieldToType[fieldName]
	if !ok {
		return nil, fmt.Errorf("no field type for field %s", fieldName)
	}

	items := []interface{}{}
	var (
		bItem      []byte
		stringItem string
		doubleItem float64
		arrayItem  []interface{}
	)
	for q.Next() {
		if fieldType == util.ArrayField {
			if err := q.Scan(&bItem); err != nil {
				return nil, err
			}
			if err := json.Unmarshal(bItem, &arrayItem); err != nil {
				return nil, err
			}
			items = append(items, arrayItem...)
		} else if fieldType == util.NumberField {
			if err := q.Scan(&doubleItem); err != nil {
				return nil, err
			}
			items = append(items, doubleItem)
		} else {
			if err := q.Scan(&stringItem); err != nil {
				return nil, err
			}
			items = append(items, stringItem)
		}
	}

	return items, nil
}

func (s *Store) LastEntries(
	tableName string, limit int) ([]map[string]interface{}, error) {
	idName := tableIDName(tableName)
	q, err := s.db.Query(fmt.Sprintf(`
		SELECT %s, Payload FROM %s ORDER BY %s DESC LIMIT %d
		`, idName, tableName, idName, limit))
	if err != nil {
		return nil, err
	}
	defer q.Close()
	return getEntries(q)
}

func getEntries(q *sql.Rows) ([]map[string]interface{}, error) {
	entries := []map[string]interface{}{}
	var bEntry []byte
	var id int
	for q.Next() {
		if err := q.Scan(&id, &bEntry); err != nil {
			return nil, err
		}
		var entry map[string]interface{}
		if err := json.Unmarshal(bEntry, &entry); err != nil {
			return nil, err
		}
		entry[util.UniqueIDKey] = id
		entries = append(entries, entry)
	}

	return entries, nil
}

// Parse number range string to SQL WHERE condition.
// Number range can be: [3,5], [3,5), [3,), (3,), (,5], (,5).
func parseNumberRange(fieldName, numRange string) (string, error) {
	numRange = strings.TrimSpace(numRange)

	l := len(numRange)
	if l < 4 {
		return "", fmt.Errorf("invalid number range %s", numRange)
	}

	first := numRange[0:1]
	last := numRange[l-1 : l]
	if (first != "[" && first != "(") ||
		(last != "]" && last != ")") {
		return "", fmt.Errorf("invalid number range %s", numRange)
	}

	parts := strings.Split(numRange[1:l-1], ",")
	if len(parts) != 2 {
		return "", fmt.Errorf("invalid number range %s", numRange)
	}

	lowerStr := strings.TrimSpace(parts[0])
	upperStr := strings.TrimSpace(parts[1])
	if lowerStr == "" && upperStr == "" {
		return "", fmt.Errorf("invalid number range %s", numRange)
	}

	var res, op string

	if lowerStr != "" {
		if _, err := strconv.ParseFloat(lowerStr, 64); err != nil {
			return "", fmt.Errorf("invalid number range %s", numRange)
		}
		if first == "[" {
			op = ">="
		} else { // "("
			op = ">"
		}
		res = fmt.Sprintf("%s %s %s", fieldName, op, lowerStr)
	}

	if upperStr != "" {
		if _, err := strconv.ParseFloat(upperStr, 64); err != nil {
			return "", fmt.Errorf("invalid number range %s", numRange)
		}
		if last == "]" {
			op = "<="
		} else { // ")"
			op = "<"
		}
		if res != "" {
			res += " AND "
		}
		res += fmt.Sprintf("%s %s %s", fieldName, op, upperStr)
	}

	return res, nil
}
