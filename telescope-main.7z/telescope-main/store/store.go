package store

import (
	"database/sql"
	"encoding/json"
	"fmt"

	"github.com/SalieriAI/telescope/util"
	_ "github.com/go-sql-driver/mysql"
)

type Store struct {
	db     *sql.DB
	dbName string
}

func New() (*Store, error) {
	dbName := util.MustGetenv("MYSQL_DB_NAME")

	db, err := sql.Open("mysql", connectionString(
		util.MustGetenv("MYSQL_HOST_ADDRESS"),
		dbName,
		util.MustGetenv("MYSQL_USERNAME"),
		util.MustGetenv("MYSQL_PASSWORD")))
	if err != nil {
		return nil, err
	}

	return &Store{
		db:     db,
		dbName: dbName,
	}, nil
}

func connectionString(address, dbName, username, password string) string {
	return fmt.Sprintf("%s:%s@tcp(%s:3306)/%s?parseTime=true&loc=Local",
		username, password, address, dbName)
}

func tableIDName(tableName string) string {
	return fmt.Sprintf("%sId", tableName)
}

func sqlFormatJSON(obj interface{}) (sql.NullString, error) {
	var res sql.NullString

	if obj == nil {
		res = sql.NullString{Valid: false}
	} else {
		jsonBytes, err := json.Marshal(obj)
		if err != nil {
			return res, err
		}
		res = sql.NullString{String: string(jsonBytes), Valid: true}
	}

	return res, nil
}
