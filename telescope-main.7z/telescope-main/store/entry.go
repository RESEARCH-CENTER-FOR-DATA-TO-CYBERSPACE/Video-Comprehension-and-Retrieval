package store

import (
	"encoding/json"
	"fmt"

	"github.com/SalieriAI/telescope/util"
)

func (s *Store) GetEntry(tableName string, id int) (map[string]interface{}, error) {
	if !s.HasTable(tableName) {
		return nil, fmt.Errorf("cannot find table %s", tableName)
	}

	var bPayload []byte

	query := fmt.Sprintf("SELECT Payload FROM %s WHERE %s = ?",
		tableName, tableIDName(tableName))

	if err := s.db.QueryRow(query, id).Scan(&bPayload); err != nil {
		return nil, err
	}

	var payload map[string]interface{}
	if err := json.Unmarshal(bPayload, &payload); err != nil {
		return nil, err
	}

	return payload, nil
}

func (s *Store) AddEntries(tableName string, dataEntries []map[string]interface{}) (int, error) {
	if !s.HasTable(tableName) {
		return -1, fmt.Errorf("cannot find table %s", tableName)
	}

	var lastID int
	if err := s.db.QueryRow(fmt.Sprintf(`
	SELECT COALESCE(MAX(%s), 0) FROM %s
	`, tableIDName(tableName), tableName)).Scan(&lastID); err != nil {
		return -1, err
	}

	sqlTableIndexFieldToType, err := s.SqlTableIndexFieldToType(tableName)
	if err != nil {
		return -1, err
	}
	var valPlaceholderStmt, fieldStmt string
	sqlIndexFields := []string{} // This is to remember the order.
	for f := range sqlTableIndexFieldToType {
		valPlaceholderStmt += ",?"
		fieldStmt += fmt.Sprintf(",%s", f)
		sqlIndexFields = append(sqlIndexFields, f)
	}

	tx, err := s.db.Begin()
	if err != nil {
		return -1, err
	}

	stmt, err := tx.Prepare(fmt.Sprintf(`
	INSERT INTO %s (Payload%s) VALUES (?%s)
	`, tableName, fieldStmt, valPlaceholderStmt))
	if err != nil {
		tx.Rollback()
		return -1, err
	}

	for _, entry := range dataEntries {
		payload, err := sqlFormatJSON(entry)
		if err != nil {
			tx.Rollback()
			return -1, err
		}

		sqlValList, err := extractSqlIndexFieldValueList(
			entry, sqlTableIndexFieldToType, sqlIndexFields)
		if err != nil {
			return -1, err
		}

		valList := append([]interface{}{payload}, sqlValList...)
		if _, err := stmt.Exec(valList...); err != nil {
			tx.Rollback()
			return -1, err
		}
	}

	return lastID + 1, tx.Commit()
}

func (s *Store) UpdateEntries(tableName string, dataEntries []map[string]interface{}) error {
	if !s.HasTable(tableName) {
		return fmt.Errorf("cannot find table %s", tableName)
	}

	sqlTableIndexFieldToType, err := s.SqlTableIndexFieldToType(tableName)
	if err != nil {
		return err
	}
	var fieldStmt string
	sqlIndexFields := []string{} // This is to remember the order.
	for f := range sqlTableIndexFieldToType {
		fieldStmt += fmt.Sprintf(", %s = ?", f)
		sqlIndexFields = append(sqlIndexFields, f)
	}

	tx, err := s.db.Begin()
	if err != nil {
		return err
	}

	stmt, err := tx.Prepare(fmt.Sprintf(`
	UPDATE %s SET Payload = ?%s WHERE %s = ?
	`, tableName, fieldStmt, tableIDName(tableName)))
	if err != nil {
		tx.Rollback()
		return err
	}

	for _, entry := range dataEntries {
		id, ok := entry[util.UniqueIDKey]
		if !ok {
			return fmt.Errorf("no %s field in entry: %+v", util.UniqueIDKey, entry)
		}

		payload, err := sqlFormatJSON(entry)
		if err != nil {
			tx.Rollback()
			return err
		}

		sqlValList, err := extractSqlIndexFieldValueList(
			entry, sqlTableIndexFieldToType, sqlIndexFields)
		if err != nil {
			return err
		}
		valList := append([]interface{}{payload}, sqlValList...)
		valList = append(valList, id)

		if _, err := stmt.Exec(valList...); err != nil {
			tx.Rollback()
			return err
		}
	}

	return tx.Commit()
}

func extractSqlIndexFieldValueList(
	entry map[string]interface{},
	sqlTableIndexFieldToType map[string]string,
	sqlIndexFields []string,
) ([]interface{}, error) {
	res := []interface{}{}
	for _, fieldName := range sqlIndexFields {
		val, ok := entry[fieldName]
		if !ok {
			return nil, fmt.Errorf("no %s in entry %v", fieldName, entry)
		}

		if sqlTableIndexFieldToType[fieldName] == util.ArrayField {
			fVal, err := sqlFormatJSON(val)
			if err != nil {
				return nil, err
			}
			res = append(res, fVal)
		} else {
			res = append(res, val)
		}
	}
	return res, nil
}
