package retriever

import (
	"encoding/json"
	"fmt"
	"strings"

	"github.com/SalieriAI/telescope/util"
	"github.com/typesense/typesense-go/typesense/api"
)

const (
	maxChunkSize           = 2000
	chunkOverlap           = 200
	defaultEmbeddingModel  = "ts/multilingual-e5-large"
	embeddingFieldTemplate = `
	{
		"name": "%s",
		"type": "float[]",
		"embed": {
			"from": ["%s"],
			"model_config": {
				"model_name": "%s"
			}
		}
	}
	`
)

func (r *Retriever) CreateTable(
	tableName, embeddingModel string,
	indexFields []*IndexField,
) error {
	if r.store.HasTable(tableName) {
		return fmt.Errorf("table %s is already created", tableName)
	}

	if strings.TrimSpace(embeddingModel) == "" {
		embeddingModel = defaultEmbeddingModel
	}

	// Create search index table for each field of type shortText and longText.
	indexFieldToType := map[string]string{}
	for _, indexField := range indexFields {
		if !util.ValidateFieldType(indexField.Type) {
			return fmt.Errorf("unsupported field type %s", indexField.Type)
		}

		indexFieldToType[indexField.Name] = indexField.Type

		if t := indexField.Type; t != util.ShortTextField && t != util.LongTextField {
			continue
		}

		apiFields := []api.Field{
			{
				Name: indexField.Name,
				Type: "string",
			},
		}
		eField, err := embeddingField(indexField.Name, embeddingModel)
		if err != nil {
			return err
		}
		apiFields = append(apiFields, eField)

		if _, err := r.client.Collections().Create(r.ctx, &api.CollectionSchema{
			Name:   indexTableName(tableName, indexField.Name),
			Fields: apiFields,
		}); err != nil {
			return err
		}
	}

	return r.store.AddTable(tableName, indexFieldToType)
}

func embeddingField(fromFieldName, embeddingModel string) (api.Field, error) {
	var field api.Field
	jsonStr := fmt.Sprintf(embeddingFieldTemplate,
		embeddingFieldName(fromFieldName), fromFieldName, embeddingModel)
	err := json.Unmarshal([]byte(jsonStr), &field)
	return field, err
}

func chunkLongString(input string) []string {
	if len(input) <= maxChunkSize {
		return []string{input}
	}

	chunks := []string{}
	for _, paragraph := range strings.Split(input, "\n") {
		paragraph = strings.TrimSpace(paragraph)
		l := len(paragraph)

		if l == 0 {
			continue
		}

		if l <= maxChunkSize {
			chunks = append(chunks, paragraph)
			continue
		}

		for i := 0; i < l; i += (maxChunkSize - chunkOverlap) {
			end := i + maxChunkSize
			if end > l {
				chunks = append(chunks, paragraph[i:l])
				break
			}
			chunks = append(chunks, paragraph[i:end])
		}
	}

	return chunks
}
