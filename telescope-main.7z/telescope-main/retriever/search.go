package retriever

import (
	"fmt"
	"strconv"

	"github.com/SalieriAI/telescope/util"
	"github.com/typesense/typesense-go/typesense/api"
)

type FullTextHit struct {
	Entry     map[string]interface{} `json:"entry"`
	TextMatch int64                  `json:"textMatch"`
}

type VectorHit struct {
	Entry          map[string]interface{} `json:"entry"`
	VectorDistance float32                `json:"vectorDistance"`
}

type Hit struct {
	FullTextHit []*FullTextHit           `json:"fullTextHit"`
	VectorHit   []*VectorHit             `json:"vectorHit"`
	MatchHit    []map[string]interface{} `json:"matchHit"`
}

func (r *Retriever) Search(
	tableName, fieldName, query string,
) (*Hit, error) {
	indexFieldToType, err := r.store.TableIndexFieldToType(tableName)
	if err != nil {
		return nil, err
	}

	fieldType, ok := indexFieldToType[fieldName]
	if !ok {
		return nil, fmt.Errorf("cannot find field type for %s in table %s",
			fieldName, tableName)
	}

	if fieldType == util.ShortTextField || fieldType == util.LongTextField {
		return r.typesenseSearch(tableName, fieldName, query)
	}
	return r.mysqlSearch(fieldType, tableName, fieldName, query)
}

func (r *Retriever) typesenseSearch(
	tableName, fieldName, query string,
) (*Hit, error) {
	getEntry := func(hitDoc map[string]interface{}) (map[string]interface{}, error) {
		idStr, ok := hitDoc[util.UniqueIDKey]
		if !ok {
			return nil, fmt.Errorf("missing %s in hit document %+v", util.UniqueIDKey, hitDoc)
		}
		id, err := strconv.Atoi(idStr.(string))
		if err != nil {
			return nil, fmt.Errorf("wrong ID data type: %s", idStr)
		}
		entry, err := r.store.GetEntry(tableName, id)
		if err != nil {
			return nil, err
		}
		entry[util.UniqueIDKey] = idStr
		return entry, nil
	}

	docs := r.client.Collection(indexTableName(tableName, fieldName)).Documents()

	// Full text search.
	res, err := docs.Search(r.ctx, &api.SearchCollectionParams{
		Q:       query,
		QueryBy: fieldName,
	})
	if err != nil {
		return nil, err
	}
	fullTextHits := []*FullTextHit{}
	for _, hit := range *res.Hits {
		entry, err := getEntry(*hit.Document)
		if err != nil {
			return nil, err
		}
		fullTextHits = append(fullTextHits, &FullTextHit{
			Entry:     entry,
			TextMatch: *(hit.TextMatch),
		})
	}

	// Vector search.
	res, err = docs.Search(r.ctx, &api.SearchCollectionParams{
		Q:       query,
		QueryBy: embeddingFieldName(fieldName),
	})
	if err != nil {
		return nil, err
	}
	vectorHits := []*VectorHit{}
	for _, hit := range *res.Hits {
		entry, err := getEntry(*hit.Document)
		if err != nil {
			return nil, err
		}
		vectorHits = append(vectorHits, &VectorHit{
			Entry:          entry,
			VectorDistance: *(hit.VectorDistance),
		})
	}

	return &Hit{
		FullTextHit: fullTextHits,
		VectorHit:   vectorHits,
	}, nil
}

func (r *Retriever) mysqlSearch(
	fieldType, tableName, fieldName, query string,
) (*Hit, error) {
	var res []map[string]interface{}
	var err error

	if fieldType == util.StringField {
		res, err = r.store.StringSearch(tableName, fieldName, query)
		if err != nil {
			return nil, err
		}
	} else if fieldType == util.ArrayField {
		res, err = r.store.ArraySearch(tableName, fieldName, query)
		if err != nil {
			return nil, err
		}
	} else if fieldType == util.NumberField {
		res, err = r.store.NumberSearch(tableName, fieldName, query)
		if err != nil {
			return nil, err
		}
	} else {
		return nil, fmt.Errorf("unknown field type %s", fieldType)
	}

	return &Hit{MatchHit: res}, nil
}
