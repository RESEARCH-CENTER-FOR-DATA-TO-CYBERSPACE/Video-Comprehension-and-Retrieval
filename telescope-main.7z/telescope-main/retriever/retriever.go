package retriever

import (
	"context"
	"fmt"
	"time"

	"github.com/SalieriAI/telescope/store"
	"github.com/typesense/typesense-go/typesense"
)

type Retriever struct {
	ctx    context.Context
	client *typesense.Client
	store  *store.Store
}

type IndexField struct {
	Name string `json:"name"`
	// “short”: Use the entire string to compute embedding.
	// “long”: Chuck by \n, if still > maxChunkSize, chuck by maxChunkSize again.
	Type string `json:"type"`
}

func New(
	ctx context.Context, serverURL, apiKey string, store *store.Store,
) *Retriever {
	client := typesense.NewClient(
		typesense.WithServer(serverURL),
		typesense.WithAPIKey(apiKey),
		typesense.WithConnectionTimeout(100*time.Second))

	return &Retriever{
		ctx:    ctx,
		client: client,
		store:  store,
	}
}

func indexTableName(tableName, fieldName string) string {
	return fmt.Sprintf("%s_%s", tableName, fieldName)
}

func embeddingFieldName(name string) string {
	return fmt.Sprintf("%s_embedding", name)
}
