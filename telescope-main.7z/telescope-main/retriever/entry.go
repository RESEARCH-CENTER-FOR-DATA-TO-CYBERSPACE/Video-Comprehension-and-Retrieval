package retriever

import (
	"fmt"
	"strconv"

	"github.com/SalieriAI/telescope/util"
)

func (r *Retriever) AddEntries(
	tableName string, dataEntries []map[string]interface{}) error {
	firstID, err := r.store.AddEntries(tableName, dataEntries)
	if err != nil {
		return err
	}

	indexFieldToType, err := r.store.TableIndexFieldToType(tableName)
	if err != nil {
		return err
	}

	for id, entry := range dataEntries {
		idStr := strconv.Itoa(firstID + id)
		if err := r.upsertEntry(indexFieldToType, entry, tableName, idStr); err != nil {
			return err
		}
	}

	return nil
}

func (r *Retriever) UpdateEntries(
	tableName string, dataEntries []map[string]interface{}) error {
	if err := r.store.UpdateEntries(tableName, dataEntries); err != nil {
		return err
	}

	indexFieldToType, err := r.store.TableIndexFieldToType(tableName)
	if err != nil {
		return err
	}

	for _, entry := range dataEntries {
		id, ok := entry[util.UniqueIDKey]
		if !ok {
			return fmt.Errorf("no %s field in entry: %+v", util.UniqueIDKey, entry)
		}
		idStr := fmt.Sprintf("%v", id)
		if err := r.upsertEntry(indexFieldToType, entry, tableName, idStr); err != nil {
			return err
		}
	}

	return nil
}

func (r *Retriever) upsertEntry(
	indexFieldToType map[string]string,
	entry map[string]interface{},
	tableName, idStr string,
) error {
	for fieldName, fieldType := range indexFieldToType {
		val, ok := entry[fieldName]
		if !ok {
			return fmt.Errorf("no %s found for data entry %+v", fieldName, entry)
		}

		var chunks []string
		if fieldType == util.ShortTextField {
			chunks = []string{fmt.Sprintf("%v", val)}
		} else if fieldType == util.LongTextField {
			chunks = chunkLongString(fmt.Sprintf("%v", val))
		} else {
			continue
		}

		docs := r.client.Collection(indexTableName(tableName, fieldName)).Documents()
		for _, chunk := range chunks {
			doc := map[string]interface{}{
				util.UniqueIDKey: idStr,
				fieldName:        chunk,
			}
			if _, err := docs.Upsert(r.ctx, doc); err != nil {
				return err
			}
		}
	}
	return nil
}

func (r *Retriever) LastEntries(
	tableName string, limit int) ([]map[string]interface{}, error) {
	return r.store.LastEntries(tableName, limit)
}
